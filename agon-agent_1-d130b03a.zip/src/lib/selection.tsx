import { createContext, useContext, useState, type ReactNode } from 'react';
import type { City, MenuItem, Restaurant } from './data';

export interface SelectedItem {
  id: string;
  city: City;
  restaurant: Restaurant;
  menuItem: MenuItem;
  quantity: number;
}

interface SelectionContextValue {
  items: SelectedItem[];
  addItem: (city: City, restaurant: Restaurant, menuItem: MenuItem) => void;
  removeItem: (cityId: string, restaurantId: string, menuItemId: string) => void;
  setQuantity: (cityId: string, restaurantId: string, menuItemId: string, quantity: number) => void;
  clear: () => void;
  totalItems: number;
  totalCalories: number;
  totalPrice: number;
}

const SelectionContext = createContext<SelectionContextValue | null>(null);

function makeId(cityId: string, restaurantId: string, menuItemId: string) {
  return `${cityId}::${restaurantId}::${menuItemId}`;
}

export function SelectionProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<SelectedItem[]>([]);

  const addItem = (city: City, restaurant: Restaurant, menuItem: MenuItem) => {
    setItems((prev) => {
      const id = makeId(city.id, restaurant.id, menuItem.id);
      const existing = prev.find((i) => i.id === id);
      if (existing) {
        return prev.map((i) => (i.id === id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [...prev, { id, city, restaurant, menuItem, quantity: 1 }];
    });
  };

  const removeItem = (cityId: string, restaurantId: string, menuItemId: string) => {
    const id = makeId(cityId, restaurantId, menuItemId);
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const setQuantity = (cityId: string, restaurantId: string, menuItemId: string, quantity: number) => {
    const id = makeId(cityId, restaurantId, menuItemId);
    if (quantity <= 0) {
      setItems((prev) => prev.filter((i) => i.id !== id));
      return;
    }
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, quantity } : i)));
  };

  const clear = () => setItems([]);

  const totalItems = items.reduce((sum, i) => sum + i.quantity, 0);
  const totalCalories = items.reduce((sum, i) => sum + i.menuItem.calories * i.quantity, 0);
  const totalPrice = items.reduce((sum, i) => sum + i.menuItem.price * i.quantity, 0);

  return (
    <SelectionContext.Provider
      value={{ items, addItem, removeItem, setQuantity, clear, totalItems, totalCalories, totalPrice }}
    >
      {children}
    </SelectionContext.Provider>
  );
}

export function useSelection() {
  const ctx = useContext(SelectionContext);
  if (!ctx) throw new Error('useSelection must be used within SelectionProvider');
  return ctx;
}

export function useItemQuantity(cityId: string, restaurantId: string, menuItemId: string): number {
  const { items } = useSelection();
  const id = makeId(cityId, restaurantId, menuItemId);
  return items.find((i) => i.id === id)?.quantity || 0;
}
