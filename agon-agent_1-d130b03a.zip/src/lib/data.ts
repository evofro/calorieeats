export type Category =
  | 'Salata'
  | 'Bowl'
  | 'Burger'
  | 'Sushi'
  | 'Pizza'
  | 'Taco'
  | 'Kahvaltı'
  | 'Makarna'
  | 'İçecek'
  | 'Tatlı';

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  calories: number;
  category: Category;
  tags: string[];
  popular?: boolean;
}

export interface Restaurant {
  id: string;
  name: string;
  cuisine: string;
  rating: number;
  reviewCount: number;
  deliveryTime: string;
  priceLevel: 1 | 2 | 3 | 4;
  image: string;
  menu: MenuItem[];
}

export interface City {
  id: string;
  name: string;
  state: string;
  description: string;
  image: string;
  restaurants: Restaurant[];
}

const cuisineImages: Record<string, string> = {
  Salata: '/images/salad-bowl.jpg',
  Bowl: '/images/vegan.jpg',
  Burger: '/images/burger.jpg',
  Sushi: '/images/sushi.jpg',
  Pizza: '/images/pizza.jpg',
  Taco: '/images/tacos.jpg',
  Kahvaltı: '/images/breakfast.jpg',
  Makarna: '/images/pasta.jpg',
  İçecek: '/images/smoothie.jpg',
  Tatlı: '/images/smoothie.jpg',
};

function r(
  id: string,
  name: string,
  cuisine: string,
  rating: number,
  reviewCount: number,
  deliveryTime: string,
  priceLevel: 1 | 2 | 3 | 4,
  menu: MenuItem[]
): Restaurant {
  return {
    id,
    name,
    cuisine,
    rating,
    reviewCount,
    deliveryTime,
    priceLevel,
    image: cuisineImages[cuisine] || '/images/hero-food.jpg',
    menu,
  };
}

function item(
  id: string,
  name: string,
  description: string,
  price: number,
  calories: number,
  category: Category,
  tags: string[] = [],
  popular = false
): MenuItem {
  return { id, name, description, price, calories, category, tags, popular };
}

export const cities: City[] = [
  {
    id: 'new-york',
    name: 'New York',
    state: 'NY',
    description:
      'Amerikanın enerji dolu metropolünde sağlıklı kafelerden gece yarısı lokantalarına kadar her lezzetin kalorisi elinizin altında.',
    image: '/images/new-york.jpg',
    restaurants: [
      r('ny-the-greensalad', 'The Greensalad', 'Salata', 4.7, 1240, '25–35 dk', 2, [
        item('ny-tgs-1', 'Kale & Kinoa Bowl', 'Kıvırcık lahana, kinoa, avokado, nar çekirdeği ve tahin sos.', 14.5, 420, 'Bowl', ['vejetaryen', 'popüler'], true),
        item('ny-tgs-2', 'Sezar Salata', 'Marul, parmesan, ev yapımı kruton ve ızgara tavuk göğsü.', 13.0, 480, 'Salata', ['tavuk'], true),
        item('ny-tgs-3', 'Akdeniz Bowl', 'Nohut, domates, salatalık, zeytin ve feta peyniri.', 12.5, 390, 'Bowl', ['vejetaryen']),
        item('ny-tgs-4', 'Avokado Toast', '2 dilim ekşi maya ekmek üzerine ezilmiş avokado ve chili pul biber.', 10.0, 350, 'Kahvaltı', ['vejetaryen']),
        item('ny-tgs-5', 'Green Goddess Wrap', 'Ispanak, feta, humus ve taze otlarla sarılmış lavaş.', 11.0, 410, 'Salata', ['vejetaryen']),
        item('ny-tgs-6', 'Detox Smoothie', 'Ispanak, elma, salatalık ve taze zencefil.', 7.5, 180, 'İçecek', ['vegan']),
      ]),
      r('ny-east-side-burger', 'East Side Burger', 'Burger', 4.5, 980, '30–40 dk', 2, [
        item('ny-esb-1', 'Classic Cheeseburger', 'Dana köfte, cheddar, marul, domates ve ev sosu.', 15.0, 720, 'Burger', ['dana'], true),
        item('ny-esb-2', 'BBQ Bacon Burger', 'Köfte, BBQ sos, çıtır pastırma ve turşu.', 17.5, 950, 'Burger', ['dana']),
        item('ny-esb-3', 'Mantarlı Swiss Burger', 'Közlenmiş mantar ve erimiş swiss peyniri.', 16.0, 780, 'Burger', ['dana']),
        item('ny-esb-4', 'Crispy Chicken Sandwich', 'Baharatlı çıtır tavuk, lahana turşusu ve ranch sos.', 14.0, 690, 'Burger', ['tavuk'], true),
        item('ny-esb-5', 'Tatlı Patates Kızartması', 'Fırınlanmış tatlı patates ve chipotle mayonez.', 6.5, 320, 'Tatlı', ['vejetaryen']),
        item('ny-esb-6', 'Vanilla Milkshake', 'Ev yapımı vanilyalı dondurma shake.', 6.0, 450, 'İçecek', []),
      ]),
      r('ny-tokyo-bay', 'Tokyo Bay Sushi', 'Sushi', 4.8, 1540, '35–50 dk', 3, [
        item('ny-tbs-1', 'Somon Avokado Roll', '8 parça taze somon ve avokado.', 14.0, 320, 'Sushi', ['balık'], true),
        item('ny-tbs-2', 'Spicy Tuna Roll', 'Baharatlı orkinos, salatalık ve susam.', 15.0, 290, 'Sushi', ['balık']),
        item('ny-tbs-3', 'Rainbow Roll', 'Kaliforniya roll üzerine çeşitli sashimi.', 18.0, 380, 'Sushi', ['balık'], true),
        item('ny-tbs-4', 'Miso Çorbası', 'Geleneksel miso, tofu ve deniz yosunu.', 4.5, 80, 'İçecek', ['vegan']),
        item('ny-tbs-5', 'Edamame', 'Tuzlu haşlanmış geniş fasulye.', 5.0, 120, 'Salata', ['vegan']),
        item('ny-tbs-6', 'Poke Bowl', 'Somon, sushilik pirinç, avokado ve turp.', 16.5, 520, 'Bowl', ['balık']),
      ]),
      r('ny-little-italy-pizza', 'Little Italy Pizza', 'Pizza', 4.6, 2100, '30–45 dk', 2, [
        item('ny-lip-1', 'Margherita Pizza', 'San Marzano domates, mozarella ve taze fesleğen.', 13.0, 720, 'Pizza', ['vejetaryen'], true),
        item('ny-lip-2', 'Pepperoni Pizza', 'Bol pepperoni ve mozzarella.', 16.0, 900, 'Pizza', []),
        item('ny-lip-3', 'Veggie Supreme', 'Biber, mantar, zeytin ve soğan.', 15.0, 780, 'Pizza', ['vejetaryen']),
        item('ny-lip-4', 'Dört Peynirli Pizza', 'Mozzarella, gorgonzola, parmesan ve ricotta.', 15.5, 860, 'Pizza', ['vejetaryen']),
        item('ny-lip-5', 'Sarımsaklı Düğümler', 'Tereyağlı sarımsaklı pizza hamuru.', 6.0, 280, 'Tatlı', ['vejetaryen']),
        item('ny-lip-6', 'Tiramisu', 'Kahveli İtalyan tatlısı.', 8.0, 340, 'Tatlı', []),
      ]),
      r('ny-brooklyn-breakfast', 'Brooklyn Breakfast Club', 'Kahvaltı', 4.7, 860, '20–35 dk', 2, [
        item('ny-bbc-1', 'Klasik Pankek', '3 adet pankek, akçaağaç şurubu ve tereyağı.', 11.0, 540, 'Kahvaltı', ['vejetaryen'], true),
        item('ny-bbc-2', 'Eggs Benedict', 'Poşe yumurta, İngiliz muffin ve hollandez sos.', 13.5, 620, 'Kahvaltı', []),
        item('ny-bbc-3', 'Avokado & Yumurta Toast', '2 dilim sourdough üzerine avokado ve poşe yumurta.', 12.0, 430, 'Kahvaltı', ['vejetaryen']),
        item('ny-bbc-4', 'Breakfast Burrito', 'Yumurta, peynir, salsa ve avokado.', 12.5, 710, 'Kahvaltı', []),
        item('ny-bbc-5', 'Yunan Yoğurt Parfe', 'Granola, ballı yoğurt ve taze meyve.', 8.5, 280, 'Kahvaltı', ['vejetaryen']),
        item('ny-bbc-6', 'Yulaf Sütü Latte', 'Espresso ve yulaf sütü.', 5.5, 120, 'İçecek', ['vegan']),
      ]),
      r('ny-chelsea-juice', 'Chelsea Juice Bar', 'İçecek', 4.4, 540, '15–25 dk', 1, [
        item('ny-cjb-1', 'Green Glow Smoothie', 'Kale, elma, limon ve zencefil.', 8.5, 210, 'İçecek', ['vegan']),
        item('ny-cjb-2', 'Berry Blast Smoothie', 'Çilek, yaban mersini, muz ve hindistan cevizi suyu.', 9.0, 260, 'İçecek', ['vegan'], true),
        item('ny-cjb-3', 'Protein Power Bowl', 'Muz, protein tozu, fıstık ezmesi ve chia.', 10.5, 340, 'Bowl', ['vejetaryen']),
        item('ny-cjb-4', 'Cold Brew Coffee', 'Soğuk demlenmiş kahve.', 5.0, 20, 'İçecek', ['vegan']),
        item('ny-cjb-5', 'Taze Portakal Suyu', 'Günlük sıkılmış portakal.', 6.0, 160, 'İçecek', ['vegan']),
        item('ny-cjb-6', 'Chia Puding', 'Hindistan cevizi sütü ve taze meyve.', 7.5, 240, 'Tatlı', ['vegan']),
      ]),
    ],
  },
  {
    id: 'los-angeles',
    name: 'Los Angeles',
    state: 'CA',
    description:
      'Gün batımı kıyı şeridinde sağlıklı bowl’lardan nefis smash burger’lara, her tabağın kalori bilgisiyle keşfedin.',
    image: '/images/los-angeles.jpg',
    restaurants: [
      r('la-santa-monica-bowls', 'Santa Monica Bowls', 'Bowl', 4.8, 1120, '25–35 dk', 2, [
        item('la-smb-1', 'Açaí Bowl', 'Açaí, muz, granola ve taze meyve.', 11.5, 380, 'Bowl', ['vegan'], true),
        item('la-smb-2', 'Buddha Bowl', 'Nohut, avokado, tahıl ve turuncu sos.', 13.5, 470, 'Bowl', ['vegan']),
        item('la-smb-3', 'Akdeniz Tahıl Bowl', 'Kinoa, domates, salatalık, zeytin ve humus.', 12.5, 450, 'Bowl', ['vejetaryen']),
        item('la-smb-4', 'Teriyaki Tofu Bowl', 'Kızarmış tofu, brokoli ve sushilik pirinç.', 13.0, 510, 'Bowl', ['vegan'], true),
        item('la-smb-5', 'Hindistan Cevizli Yoğurt Bowl', 'Coconut yogurt, chia ve yaban mersini.', 9.5, 320, 'Bowl', ['vegan']),
        item('la-smb-6', 'Matcha Latte', 'Japon matcha ve badem sütü.', 5.5, 140, 'İçecek', ['vegan']),
      ]),
      r('la-sunset-smash', 'Sunset Smash Burger', 'Burger', 4.6, 1340, '30–40 dk', 2, [
        item('la-ssb-1', 'Smash Burger', 'İnce dana köfte, cheddar, turşu ve karamelize soğan.', 13.5, 680, 'Burger', ['dana'], true),
        item('la-ssb-2', 'Double Smash', 'Çift kat köfte ve çift peynir.', 17.0, 950, 'Burger', ['dana']),
        item('la-ssb-3', 'Truffle Fries', 'Parmesan ve truffle yağı ile fırınlanmış patates.', 8.0, 420, 'Tatlı', ['vejetaryen']),
        item('la-ssb-4', 'Soğan Halkası', 'Çıtır kaplamalı soğan halkaları.', 6.5, 380, 'Tatlı', ['vejetaryen']),
        item('la-ssb-5', 'Klasik Shake', 'Vanilya dondurma milkshake.', 5.5, 430, 'İçecek', []),
        item('la-ssb-6', 'Veggie Burger', 'Kara lahana köftesi ve guacamole.', 12.5, 560, 'Burger', ['vegan'], true),
      ]),
      r('la-venice-sushi', 'Venice Sushi Spot', 'Sushi', 4.7, 980, '35–50 dk', 3, [
        item('la-vss-1', 'California Roll', 'Yengeç, avokado ve salatalık.', 11.0, 310, 'Sushi', ['balık'], true),
        item('la-vss-2', 'Dragon Roll', 'Yengeç içi, avokado ve kabayaki sos.', 17.0, 420, 'Sushi', ['balık']),
        item('la-vss-3', 'Sashimi Tabak', '9 parça taze sashimi çeşidi.', 21.0, 250, 'Sushi', ['balık']),
        item('la-vss-4', 'Tempura Roll', 'Karides tempura ve baharatlı mayonez.', 15.0, 480, 'Sushi', ['balık']),
        item('la-vss-5', 'Yosun Salatası', 'Susam soslu deniz yosanı salatası.', 6.5, 110, 'Salata', ['vegan']),
        item('la-vss-6', 'Mochi Dondurma', '3 adet pirinç kekli dondurma.', 7.0, 220, 'Tatlı', []),
      ]),
      r('la-cali-tacos', 'Cali Taco Truck', 'Taco', 4.5, 1560, '20–35 dk', 1, [
        item('la-ctt-1', 'Carne Asada Tacos', '3 adet ızgara dana eti tacos.', 12.0, 520, 'Taco', ['dana'], true),
        item('la-ctt-2', 'Fish Tacos', '2 adet çıtır balık tacos ve lahana salatası.', 11.5, 480, 'Taco', ['balık'], true),
        item('la-ctt-3', 'Chicken Tinga Quesadilla', 'Baharatlı tavuk ve erimiş peynir.', 10.5, 590, 'Taco', ['tavuk']),
        item('la-ctt-4', 'Loaded Nachos', 'Bol peynirli, jalapenolu ve guacamolelu nachos.', 9.5, 720, 'Taco', []),
        item('la-ctt-5', 'Street Corn', 'Mayonezli, peynirli mısır koçanı.', 6.0, 240, 'Tatlı', ['vejetaryen']),
        item('la-ctt-6', 'Horchata', 'Tarcınlı pirinç içeceği.', 4.5, 200, 'İçecek', []),
      ]),
      r('la-beverly-hills-pasta', 'Beverly Hills Pasta', 'Makarna', 4.6, 870, '30–45 dk', 3, [
        item('la-bhp-1', 'Fettuccine Alfredo', 'Krema, tereyağı ve parmesan soslu.', 16.0, 820, 'Makarna', ['vejetaryen'], true),
        item('la-bhp-2', 'Spaghetti Bolognese', 'Geleneksel İtalyan kıymalı sos.', 15.5, 780, 'Makarna', []),
        item('la-bhp-3', 'Pesto Chicken Pasta', 'Fesleğen pesto ve ızgara tavuk.', 16.5, 740, 'Makarna', ['tavuk']),
        item('la-bhp-4', 'Penne Arrabbiata', 'Acılı domates sos ve sarımsak.', 14.0, 620, 'Makarna', ['vejetaryen']),
        item('la-bhp-5', 'Sezar Yan Salata', 'Marul, kruton ve parmesan.', 7.0, 220, 'Salata', []),
        item('la-bhp-6', 'Tiramisu', 'Kahveli İtalyan tatlısı.', 8.5, 350, 'Tatlı', []),
      ]),
      r('la-laurel-smoothie', 'Laurel Canyon Smoothie Co', 'İçecek', 4.5, 620, '15–25 dk', 1, [
        item('la-lcs-1', 'Tropical Green Smoothie', 'Ispanak, mango, ananas ve hindistan cevizi suyu.', 9.0, 230, 'İçecek', ['vegan']),
        item('la-lcs-2', 'Peanut Butter Protein', 'Muz, fıstık ezmesi ve protein tozu.', 10.0, 390, 'İçecek', ['vejetaryen'], true),
        item('la-lcs-3', 'Blue Spirulina Bowl', 'Spirulina, muz ve granola.', 12.0, 340, 'Bowl', ['vegan']),
        item('la-lcs-4', 'Kombucha', 'Canlı fermente çay.', 5.5, 40, 'İçecek', ['vegan']),
        item('la-lcs-5', 'Badem Ezmeli Toast', '2 dilim tam tahıllı ekmek üzerine badem ezmesi ve muz.', 8.5, 330, 'Kahvaltı', ['vejetaryen']),
        item('la-lcs-6', 'Buzlu Matcha', 'Japon matcha ve badem sütü.', 6.0, 90, 'İçecek', ['vegan']),
      ]),
    ],
  },
  {
    id: 'miami',
    name: 'Miami',
    state: 'FL',
    description:
      'Tropikal esintili Miami’de Latin lezzetleri, deniz ürünleri ve hafif bowl’ların kalori detaylarıyla tanışın.',
    image: '/images/miami.jpg',
    restaurants: [
      r('mia-south-beach-salad', 'South Beach Salad', 'Salata', 4.6, 890, '20–30 dk', 2, [
        item('mia-sbs-1', 'Beachside Cobb', 'Marul, tavuk, yumurta, avokado, domates ve blue peynir.', 14.0, 560, 'Salata', ['tavuk'], true),
        item('mia-sbs-2', 'Citrus Karides Salata', 'Izgara karides, portakal dilimleri ve avokado.', 15.5, 420, 'Salata', ['deniz ürünleri'], true),
        item('mia-sbs-3', 'Karpuz Feta Salata', 'Karpuz, feta, nane ve limon sos.', 12.5, 320, 'Salata', ['vejetaryen']),
        item('mia-sbs-4', 'Kinoa Tabbule', 'Maydanoz, domates, bulgur ve nar.', 11.0, 310, 'Salata', ['vegan']),
        item('mia-sbs-5', 'Izgara Tavuk Wrap', 'Tavuk, humus ve taze sebzelerle sarılmış.', 12.0, 480, 'Salata', ['tavuk']),
        item('mia-sbs-6', 'Buzlu Çay', 'Ev yapımı limonlu buzlu çay.', 4.0, 10, 'İçecek', []),
      ]),
      r('mia-wynwood-tacos', 'Wynwood Taco House', 'Taco', 4.7, 1430, '25–40 dk', 2, [
        item('mia-wth-1', 'Carnitas Tacos', '3 adet yavaş pişmiş domuz eti tacos.', 11.5, 540, 'Taco', ['domuz'], true),
        item('mia-wth-2', 'Shrimp Tacos', '2 adet ızgara karides tacos.', 12.5, 450, 'Taco', ['deniz ürünleri'], true),
        item('mia-wth-3', 'Barbacoa Burrito', 'Dana eti, pirinç, fasulye ve salsa.', 13.0, 780, 'Taco', ['dana']),
        item('mia-wth-4', 'Elote', 'Meksika usulü mısır koçanı.', 5.5, 260, 'Tatlı', ['vejetaryen']),
        item('mia-wth-5', 'Guacamole & Cips', 'Taze guacamole ve tortilla cips.', 8.5, 430, 'Tatlı', ['vejetaryen']),
        item('mia-wth-6', 'Margarita Mocktail', 'Tuzlu kenarlı lime mocktail.', 6.0, 140, 'İçecek', []),
      ]),
      r('mia-brickell-sushi', 'Brickell Sushi Lounge', 'Sushi', 4.8, 1080, '35–50 dk', 3, [
        item('mia-bsl-1', 'Miami Heat Roll', 'Baharatlı orkinos, avokado ve jalapeno.', 16.0, 360, 'Sushi', ['balık'], true),
        item('mia-bsl-2', 'Tropical Salmon Roll', 'Somon, mango ve avokado.', 15.5, 340, 'Sushi', ['balık']),
        item('mia-bsl-3', 'Volcano Roll', 'Baharatlı karides ve kaplanmış somon.', 18.0, 450, 'Sushi', ['balık']),
        item('mia-bsl-4', 'Gyoza', '6 adet sebzeli çin mantısı.', 8.5, 280, 'Tatlı', ['vejetaryen']),
        item('mia-bsl-5', 'Miso Glaze Patlıcan', 'Fırınlanmış patlıcan ve miso sos.', 9.0, 210, 'Salata', ['vegan']),
        item('mia-bsl-6', 'Lychee Sorbet', 'Taze liçi sorbe.', 7.5, 180, 'Tatlı', []),
      ]),
      r('mia-coconut-grove-pizza', 'Coconut Grove Pizza', 'Pizza', 4.5, 1250, '30–45 dk', 2, [
        item('mia-cgp-1', 'Margherita', 'Domates sos, mozzarella ve fesleğen.', 14.0, 700, 'Pizza', ['vejetaryen'], true),
        item('mia-cgp-2', 'Prosciutto & Roka', 'İtalyan prosciutto ve taze roka.', 17.0, 820, 'Pizza', []),
        item('mia-cgp-3', 'BBQ Tavuk Pizza', 'Izgara tavuk, BBQ sos ve kırmızı soğan.', 16.5, 880, 'Pizza', ['tavuk']),
        item('mia-cgp-4', 'Beyaz Pizza', 'Ricotta, mozzarella ve sarımsaklı zeytinyağı.', 15.5, 790, 'Pizza', ['vejetaryen']),
        item('mia-cgp-5', 'Caprese Salata', 'Domates, mozzarella ve fesleğen.', 9.0, 280, 'Salata', ['vejetaryen']),
        item('mia-cgp-6', 'Cannoli', 'İtalyan kremalı tatlı.', 6.5, 240, 'Tatlı', []),
      ]),
      r('mia-miami-shores-breakfast', 'Miami Shores Breakfast', 'Kahvaltı', 4.6, 760, '20–35 dk', 2, [
        item('mia-msb-1', 'Cuban Toast & Cafe con Leche', 'Tereyağlı Küba tost ve sütlü kahve.', 8.5, 420, 'Kahvaltı', []),
        item('mia-msb-2', 'Tropikal Meyve Bowl', 'Papaya, ananas, mango ve hindistan cevizi.', 10.0, 260, 'Kahvaltı', ['vegan'], true),
        item('mia-msb-3', 'Huevos Rancheros', 'Kızarmış tortilla üzerine salsa ve yumurta.', 12.5, 580, 'Kahvaltı', ['vejetaryen']),
        item('mia-msb-4', 'Kruvasan Sandviç', 'Tereyağlı kruvasan, yumurta ve peynir.', 11.0, 520, 'Kahvaltı', []),
        item('mia-msb-5', 'Chia Mango Puding', 'Chia tohumu, mango ve hindistan cevizi sütü.', 8.0, 240, 'Kahvaltı', ['vegan']),
        item('mia-msb-6', 'Cortadito', 'Küba usulü sütlü espresso.', 4.5, 80, 'İçecek', []),
      ]),
      r('mia-little-havana-bowl', 'Little Havana Bowl', 'Bowl', 4.5, 920, '25–40 dk', 2, [
        item('mia-lhb-1', 'Cuban Bowl', 'Pirinç, siyah fasulye, domuz ve tatlı patates.', 13.5, 670, 'Bowl', ['domuz'], true),
        item('mia-lhb-2', 'Ropa Vieja Bowl', 'Yavaş pişmiş dana eti ve biberli pilav.', 14.0, 640, 'Bowl', ['dana']),
        item('mia-lhb-3', 'Plantain & Black Bean Bowl', 'Kızarmış plantain, fasulye ve avokado.', 12.5, 590, 'Bowl', ['vegan']),
        item('mia-lhb-4', 'Mojo Tavuk Bowl', 'Narenciyeli mojo soslu tavuk.', 13.0, 610, 'Bowl', ['tavuk']),
        item('mia-lhb-5', 'Yuca Fries', 'Kızarmış yuka kökü.', 6.5, 340, 'Tatlı', ['vegan']),
        item('mia-lhb-6', 'Passion Fruit Smoothie', 'Çarkıfelek meyvesi, muz ve portakal.', 7.0, 200, 'İçecek', ['vegan']),
      ]),
    ],
  },
];

export function getCityById(id: string): City | undefined {
  return cities.find((c) => c.id === id);
}

export function getRestaurantById(cityId: string, restaurantId: string): { city: City; restaurant: Restaurant } | undefined {
  const city = getCityById(cityId);
  if (!city) return undefined;
  const restaurant = city.restaurants.find((r) => r.id === restaurantId);
  if (!restaurant) return undefined;
  return { city, restaurant };
}

export function getAllCuisines(city: City): string[] {
  const set = new Set(city.restaurants.map((r) => r.cuisine));
  return Array.from(set).sort();
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
}

export function calorieLabel(calories: number): 'low' | 'medium' | 'high' {
  if (calories <= 350) return 'low';
  if (calories <= 700) return 'medium';
  return 'high';
}
