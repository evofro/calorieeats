import { Link } from 'react-router-dom';
import { Leaf, Utensils } from 'lucide-react';
import { useSelection } from '../lib/selection';

export function Header() {
  const { totalItems } = useSelection();

  return (
    <header className="sticky top-0 z-50 glass-card border-b border-white/60">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2 transition-transform hover:scale-[1.02]">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FF8C69] text-white shadow-md">
            <Leaf className="h-5 w-5" />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="font-display text-xl font-bold tracking-tight text-[#3D3D3D]">CalorieEats</span>
            <span className="text-xs font-medium text-[#8C8C8C]">Menüler & Kaloriler</span>
          </div>
        </Link>

        <div className="flex items-center gap-4">
          <Link
            to="/"
            className="hidden items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold text-[#6B8E6B] transition-colors hover:bg-[#A8C6A8]/20 sm:flex"
          >
            <Utensils className="h-4 w-4" />
            Şehirler
          </Link>
          <div className="relative">
            <div className="flex h-10 items-center gap-2 rounded-full bg-white px-4 shadow-sm">
              <span className="text-sm font-semibold text-[#3D3D3D]">Tabağım</span>
              <span className="flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-[#FF8C69] px-1.5 text-xs font-bold text-white">
                {totalItems}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
