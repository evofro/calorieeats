import { Minus, Plus, Flame, TrendingUp, Leaf } from 'lucide-react';
import type { City, MenuItem, Restaurant } from '../lib/data';
import { formatCurrency, calorieLabel } from '../lib/data';
import { useSelection, useItemQuantity } from '../lib/selection';

interface MenuItemCardProps {
  city: City;
  restaurant: Restaurant;
  item: MenuItem;
}

export function MenuItemCard({ city, restaurant, item }: MenuItemCardProps) {
  const { addItem, setQuantity } = useSelection();
  const quantity = useItemQuantity(city.id, restaurant.id, item.id);

  const calorieVariant = calorieLabel(item.calories);
  const calorieColor =
    calorieVariant === 'low' ? 'bg-[#A8C6A8] text-white' : calorieVariant === 'medium' ? 'bg-[#FFD8C2] text-[#8C5A3C]' : 'bg-[#FF8C69] text-white';

  return (
    <div className="flex flex-col justify-between rounded-2xl bg-white p-5 shadow-sm transition-shadow hover:shadow-md sm:flex-row sm:items-center sm:gap-5">
      <div className="flex flex-1 gap-4">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#FFF8F0] text-[#FF8C69]">
          <MenuIcon category={item.category} />
        </div>
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h4 className="font-display text-lg font-bold text-[#3D3D3D]">{item.name}</h4>
            {item.popular && (
              <span className="flex items-center gap-1 rounded-full bg-[#FF8C69]/10 px-2 py-0.5 text-xs font-bold text-[#FF8C69]">
                <TrendingUp className="h-3 w-3" /> Popüler
              </span>
            )}
          </div>
          <p className="mt-1 text-sm leading-relaxed text-[#8C8C8C]">{item.description}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            {item.tags.map((tag) => (
              <span
                key={tag}
                className="rounded-full border border-[#A8C6A8]/40 bg-[#A8C6A8]/10 px-2 py-0.5 text-xs font-medium text-[#6B8E6B]"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between gap-4 sm:mt-0 sm:flex-col sm:items-end">
        <div className="flex items-center gap-3">
          <span className="font-display text-xl font-bold text-[#3D3D3D]">{formatCurrency(item.price)}</span>
          <span className={`flex items-center gap-1 rounded-full px-2 py-1 text-xs font-bold ${calorieColor}`}>
            <Flame className="h-3 w-3" />
            {item.calories} kcal
          </span>
        </div>

        {quantity === 0 ? (
          <button
            onClick={() => addItem(city, restaurant, item)}
            className="flex items-center gap-2 rounded-full bg-[#FF8C69] px-4 py-2 text-sm font-bold text-white shadow-md transition-transform hover:scale-105 active:scale-95"
          >
            <Plus className="h-4 w-4" /> Ekle
          </button>
        ) : (
          <div className="flex items-center gap-2 rounded-full bg-[#FFF8F0] p-1">
            <button
              onClick={() => setQuantity(city.id, restaurant.id, item.id, quantity - 1)}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-[#FF8C69] shadow-sm transition-colors hover:bg-[#FF8C69] hover:text-white"
              aria-label="Azalt"
            >
              <Minus className="h-4 w-4" />
            </button>
            <span className="min-w-[1.5rem] text-center text-sm font-bold text-[#3D3D3D]">{quantity}</span>
            <button
              onClick={() => addItem(city, restaurant, item)}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-[#FF8C69] shadow-sm transition-colors hover:bg-[#FF8C69] hover:text-white"
              aria-label="Artır"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function MenuIcon({ category }: { category: string }) {
  switch (category) {
    case 'Salata':
    case 'Bowl':
      return <Leaf className="h-6 w-6" />;
    case 'Burger':
      return <span className="text-lg">🍔</span>;
    case 'Sushi':
      return <span className="text-lg">🍣</span>;
    case 'Pizza':
      return <span className="text-lg">🍕</span>;
    case 'Taco':
      return <span className="text-lg">🌮</span>;
    case 'Kahvaltı':
      return <span className="text-lg">🍳</span>;
    case 'Makarna':
      return <span className="text-lg">🍝</span>;
    case 'İçecek':
      return <span className="text-lg">🥤</span>;
    case 'Tatlı':
      return <span className="text-lg">🍰</span>;
    default:
      return <Leaf className="h-6 w-6" />;
  }
}
