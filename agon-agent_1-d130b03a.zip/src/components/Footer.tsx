import { Heart } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t border-white/60 bg-white/60 py-8">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 sm:flex-row sm:px-6 lg:px-8">
        <p className="text-sm text-[#8C8C8C]">
          © {new Date().getFullYear()} CalorieEats. Fiyatlar ve kaloriler yaklaşık demo değerlerdir.
        </p>
        <p className="flex items-center gap-1 text-sm text-[#8C8C8C]">
          <Heart className="h-4 w-4 fill-[#FF8C69] text-[#FF8C69]" /> sağlıklı seçimler için
        </p>
      </div>
    </footer>
  );
}
