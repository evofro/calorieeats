import { motion } from 'framer-motion';
import { MapPin, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { City } from '../lib/data';

interface CityCardProps {
  city: City;
  index: number;
}

export function CityCard({ city, index }: CityCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Link
        to={`/city/${city.id}`}
        className="group relative flex h-80 flex-col justify-end overflow-hidden rounded-3xl bg-white shadow-lg transition-all hover:-translate-y-1 hover:shadow-xl"
      >
        <img
          src={city.image}
          alt={city.name}
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

        <div className="relative z-10 p-6 text-white">
          <div className="mb-2 flex items-center gap-2 text-sm font-medium opacity-90">
            <MapPin className="h-4 w-4" />
            {city.state}
          </div>
          <h3 className="font-display text-3xl font-bold">{city.name}</h3>
          <p className="mt-1 line-clamp-2 text-sm opacity-90">{city.description}</p>
          <div className="mt-4 flex items-center gap-2 text-sm font-semibold">
            <span>{city.restaurants.length} restoran</span>
            <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
