import { motion } from 'framer-motion';
import { Star, Clock, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { City, Restaurant } from '../lib/data';

interface RestaurantCardProps {
  city: City;
  restaurant: Restaurant;
  index: number;
}

export function RestaurantCard({ city, restaurant, index }: RestaurantCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.06 }}
    >
      <Link
        to={`/city/${city.id}/restaurant/${restaurant.id}`}
        className="group flex h-full flex-col overflow-hidden rounded-2xl bg-white shadow-md transition-all hover:-translate-y-1 hover:shadow-lg"
      >
        <div className="relative h-44 overflow-hidden">
          <img
            src={restaurant.image}
            alt={restaurant.name}
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
            loading="lazy"
          />
          <div className="absolute right-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-xs font-bold text-[#3D3D3D] backdrop-blur">
            {restaurant.cuisine}
          </div>
        </div>

        <div className="flex flex-1 flex-col p-5">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-display text-xl font-bold text-[#3D3D3D]">{restaurant.name}</h3>
            <div className="flex items-center gap-1 rounded-full bg-[#FFF8F0] px-2 py-0.5 text-xs font-bold text-[#FF8C69]">
              <Star className="h-3 w-3 fill-[#FF8C69]" />
              {restaurant.rating}
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-[#8C8C8C]">
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {restaurant.deliveryTime}
            </span>
            <span>{restaurant.reviewCount} değerlendirme</span>
            <span className="tracking-widest text-[#A8C6A8]">{'$'.repeat(restaurant.priceLevel)}</span>
          </div>

          <div className="mt-auto flex items-center justify-between pt-4">
            <span className="text-sm font-semibold text-[#6B8E6B]">
              {restaurant.menu.length} menü öğesi
            </span>
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#FF8C69]/10 text-[#FF8C69] transition-colors group-hover:bg-[#FF8C69] group-hover:text-white">
              <ChevronRight className="h-4 w-4" />
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
