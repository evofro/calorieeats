import { motion, AnimatePresence } from 'framer-motion';
import { Flame, DollarSign, ShoppingBag, Trash2 } from 'lucide-react';
import { useSelection } from '../lib/selection';
import { formatCurrency } from '../lib/data';

export function SelectionSummary() {
  const { totalItems, totalCalories, totalPrice, clear } = useSelection();

  return (
    <AnimatePresence>
      {totalItems > 0 && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 z-40 border-t border-white/60 bg-white/95 px-4 py-3 shadow-[0_-8px_30px_rgba(0,0,0,0.08)] backdrop-blur sm:py-4"
        >
          <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 sm:flex-row sm:px-6 lg:px-8">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FF8C69]/10 text-[#FF8C69]">
                <ShoppingBag className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-[#8C8C8C]">Tabağım</p>
                <p className="font-display text-lg font-bold text-[#3D3D3D]">
                  {totalItems} ürün
                </p>
              </div>
            </div>

            <div className="flex w-full items-center justify-between gap-6 sm:w-auto">
              <div className="flex gap-4 text-sm">
                <span className="flex items-center gap-1.5 font-semibold text-[#3D3D3D]">
                  <DollarSign className="h-4 w-4 text-[#A8C6A8]" />
                  {formatCurrency(totalPrice)}
                </span>
                <span className="flex items-center gap-1.5 font-semibold text-[#3D3D3D]">
                  <Flame className="h-4 w-4 text-[#FF8C69]" />
                  {totalCalories} kcal
                </span>
              </div>
              <button
                onClick={clear}
                className="flex h-10 w-10 items-center justify-center rounded-full text-[#8C8C8C] transition-colors hover:bg-red-50 hover:text-red-500"
                aria-label="Tabağı temizle"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
