import { useMemo, useState } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, ChevronLeft, MapPin, SlidersHorizontal } from 'lucide-react';
import { getCityById, getAllCuisines } from '../lib/data';
import { RestaurantCard } from '../components/RestaurantCard';

export function CityPage() {
  const { cityId } = useParams<{ cityId: string }>();
  const city = cityId ? getCityById(cityId) : undefined;

  const [query, setQuery] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState<string>('Tümü');

  const cuisines = useMemo(() => (city ? ['Tümü', ...getAllCuisines(city)] : []), [city]);

  const filteredRestaurants = useMemo(() => {
    if (!city) return [];
    return city.restaurants.filter((r) => {
      const matchesQuery = r.name.toLowerCase().includes(query.toLowerCase());
      const matchesCuisine = selectedCuisine === 'Tümü' || r.cuisine === selectedCuisine;
      return matchesQuery && matchesCuisine;
    });
  }, [city, query, selectedCuisine]);

  if (!city) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen">
      {/* City hero */}
      <section className="relative h-72 sm:h-80">
        <img src={city.image} alt={city.name} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#FFF8F0] via-[#FFF8F0]/60 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-7xl px-4 pb-8 sm:px-6 lg:px-8">
          <Link
            to="/"
            className="mb-3 inline-flex items-center gap-1 rounded-full bg-white/80 px-3 py-1 text-sm font-semibold text-[#6B8E6B] backdrop-blur transition-colors hover:bg-white"
          >
            <ChevronLeft className="h-4 w-4" /> Şehirlere dön
          </Link>
          <h1 className="font-display text-4xl font-bold text-[#3D3D3D] sm:text-5xl">{city.name}</h1>
          <p className="mt-2 flex items-center gap-2 text-[#8C8C8C]">
            <MapPin className="h-4 w-4" />
            {city.state} · {city.restaurants.length} restoran
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 flex flex-col gap-4 rounded-2xl bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between"
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-[#8C8C8C]" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Restoran ara..."
              className="w-full rounded-xl border border-[#FFD8C2] bg-[#FFF8F0] py-2.5 pl-10 pr-4 text-sm outline-none transition-colors focus:border-[#FF8C69] focus:ring-2 focus:ring-[#FF8C69]/20"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
            <SlidersHorizontal className="h-4 w-4 shrink-0 text-[#8C8C8C]" />
            {cuisines.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCuisine(c)}
                className={`whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-bold transition-colors ${
                  selectedCuisine === c
                    ? 'bg-[#FF8C69] text-white'
                    : 'bg-[#FFF8F0] text-[#8C8C8C] hover:bg-[#FFD8C2]/50'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </motion.div>

        {filteredRestaurants.length === 0 ? (
          <div className="rounded-2xl bg-white py-16 text-center shadow-sm">
            <p className="text-lg font-semibold text-[#3D3D3D]">Restoran bulunamadı</p>
            <p className="mt-1 text-sm text-[#8C8C8C]">Farklı bir arama veya filtre deneyin.</p>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredRestaurants.map((restaurant, index) => (
              <RestaurantCard key={restaurant.id} city={city} restaurant={restaurant} index={index} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
