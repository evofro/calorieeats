import { motion } from 'framer-motion';
import { MapPin } from 'lucide-react';
import { cities } from '../lib/data';
import { CityCard } from '../components/CityCard';

export function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative flex min-h-[70vh] items-center justify-center overflow-hidden px-4 py-24 sm:py-32">
        <img
          src="/images/hero-food.jpg"
          alt="Sağlıklı yemekler"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#FFF8F0]/95 via-[#FFF8F0]/80 to-[#FFD8C2]/70" />

        <div className="relative z-10 mx-auto max-w-4xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-flex items-center gap-2 rounded-full bg-[#A8C6A8]/20 px-4 py-1.5 text-sm font-bold text-[#6B8E6B]">
              <MapPin className="h-4 w-4" /> Şimdi 3 şehirde aktif
            </span>
            <h1 className="mt-6 font-display text-5xl font-bold leading-[1.1] text-[#3D3D3D] sm:text-6xl lg:text-7xl text-balance">
              Şehrini seç, <span className="text-[#FF8C69]">kalorini bil</span>
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-[#8C8C8C] text-balance">
              CalorieEats ile New York, Los Angeles ve Miami’deki restoranların menülerine, fiyatlarına ve her yemeğin kalori değerine anında ulaş.
            </p>
          </motion.div>
        </div>
      </section>

      {/* City selection */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-10 text-center">
          <h2 className="font-display text-3xl font-bold text-[#3D3D3D] sm:text-4xl">Şehrini Keşfet</h2>
          <p className="mt-2 text-[#8C8C8C]">Bir şehir seç ve restoran menülerini görüntüle.</p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {cities.map((city, index) => (
            <CityCard key={city.id} city={city} index={index} />
          ))}
        </div>
      </section>
    </div>
  );
}
