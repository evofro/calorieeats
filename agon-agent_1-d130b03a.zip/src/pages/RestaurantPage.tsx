import { useMemo, useState } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, Star, Clock, MapPin, Flame, ArrowUpDown } from 'lucide-react';
import { getRestaurantById, formatCurrency } from '../lib/data';
import { MenuItemCard } from '../components/MenuItemCard';

export function RestaurantPage() {
  const { cityId, restaurantId } = useParams<{ cityId: string; restaurantId: string }>();
  const result = cityId && restaurantId ? getRestaurantById(cityId, restaurantId) : undefined;

  const [sort, setSort] = useState<'default' | 'calories-asc' | 'calories-desc' | 'price-asc' | 'price-desc'>('default');
  const [activeCategory, setActiveCategory] = useState<string>('Tümü');

  const city = result?.city;
  const restaurant = result?.restaurant;

  const categories = useMemo(() => {
    if (!restaurant) return [];
    const set = new Set(restaurant.menu.map((m) => m.category));
    return ['Tümü', ...Array.from(set)];
  }, [restaurant]);

  const sortedAndFilteredMenu = useMemo(() => {
    if (!restaurant) return [];
    let list = [...restaurant.menu];
    if (activeCategory !== 'Tümü') {
      list = list.filter((m) => m.category === activeCategory);
    }
    switch (sort) {
      case 'calories-asc':
        list.sort((a, b) => a.calories - b.calories);
        break;
      case 'calories-desc':
        list.sort((a, b) => b.calories - a.calories);
        break;
      case 'price-asc':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        list.sort((a, b) => b.price - a.price);
        break;
      default:
        // keep original order but show popular first
        list.sort((a, b) => Number(b.popular) - Number(a.popular));
    }
    return list;
  }, [restaurant, sort, activeCategory]);

  if (!city || !restaurant) {
    return <Navigate to="/" replace />;
  }

  const avgCalories = Math.round(
    restaurant.menu.reduce((sum, m) => sum + m.calories, 0) / restaurant.menu.length
  );

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative h-64 sm:h-80">
        <img src={restaurant.image} alt={restaurant.name} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#FFF8F0] via-[#FFF8F0]/50 to-transparent" />
        <div className="absolute inset-x-0 top-0 mx-auto max-w-7xl px-4 pt-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-2">
            <Link
              to={`/city/${city.id}`}
              className="inline-flex items-center gap-1 rounded-full bg-white/80 px-3 py-1 text-sm font-semibold text-[#6B8E6B] backdrop-blur transition-colors hover:bg-white"
            >
              <ChevronLeft className="h-4 w-4" /> {city.name}
            </Link>
            <Link
              to="/"
              className="inline-flex items-center gap-1 rounded-full bg-white/80 px-3 py-1 text-sm font-semibold text-[#8C8C8C] backdrop-blur transition-colors hover:bg-white"
            >
              <MapPin className="h-4 w-4" /> Şehirler
            </Link>
          </div>
        </div>
        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-7xl px-4 pb-6 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-3">
            <span className="rounded-full bg-[#FF8C69] px-3 py-1 text-xs font-bold text-white">
              {restaurant.cuisine}
            </span>
            <span className="flex items-center gap-1 rounded-full bg-white/90 px-3 py-1 text-xs font-bold text-[#3D3D3D] backdrop-blur">
              <Star className="h-3.5 w-3.5 fill-[#FF8C69] text-[#FF8C69]" />
              {restaurant.rating} ({restaurant.reviewCount})
            </span>
            <span className="flex items-center gap-1 rounded-full bg-white/90 px-3 py-1 text-xs font-bold text-[#3D3D3D] backdrop-blur">
              <Clock className="h-3.5 w-3.5 text-[#A8C6A8]" />
              {restaurant.deliveryTime}
            </span>
            <span className="flex items-center gap-1 rounded-full bg-white/90 px-3 py-1 text-xs font-bold text-[#3D3D3D] backdrop-blur">
              <Flame className="h-3.5 w-3.5 text-[#FF8C69]" />
              Ort. {avgCalories} kcal
            </span>
          </div>
          <h1 className="mt-3 font-display text-4xl font-bold text-[#3D3D3D] sm:text-5xl">{restaurant.name}</h1>
          <p className="mt-1 text-sm text-[#8C8C8C]">
            {'$'.repeat(restaurant.priceLevel)} fiyat aralığı · {restaurant.menu.length} menü öğesi
          </p>
        </div>
      </section>

      {/* Menu controls */}
      <section className="mx-auto max-w-4xl px-4 py-6 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 flex flex-col gap-4 rounded-2xl bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between"
        >
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-bold transition-colors ${
                  activeCategory === cat
                    ? 'bg-[#A8C6A8] text-white'
                    : 'bg-[#FFF8F0] text-[#8C8C8C] hover:bg-[#A8C6A8]/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <ArrowUpDown className="h-4 w-4 text-[#8C8C8C]" />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as typeof sort)}
              className="rounded-xl border border-[#FFD8C2] bg-[#FFF8F0] px-3 py-2 text-sm font-semibold text-[#3D3D3D] outline-none focus:border-[#FF8C69] focus:ring-2 focus:ring-[#FF8C69]/20"
            >
              <option value="default">Öne Çıkanlar</option>
              <option value="calories-asc">Kalori: Düşükten Yükseğe</option>
              <option value="calories-desc">Kalori: Yüksekten Düşüğe</option>
              <option value="price-asc">Fiyat: Düşükten Yükseğe</option>
              <option value="price-desc">Fiyat: Yüksekten Düşüğe</option>
            </select>
          </div>
        </motion.div>

        {sortedAndFilteredMenu.length === 0 ? (
          <div className="rounded-2xl bg-white py-16 text-center shadow-sm">
            <p className="text-lg font-semibold text-[#3D3D3D]">Menü öğesi bulunamadı</p>
          </div>
        ) : (
          <div className="space-y-4">
            {sortedAndFilteredMenu.map((menuItem, index) => (
              <motion.div
                key={menuItem.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.04 }}
              >
                <MenuItemCard city={city} restaurant={restaurant} item={menuItem} />
              </motion.div>
            ))}
          </div>
        )}

        <div className="mt-8 rounded-2xl bg-[#A8C6A8]/10 p-5 text-center">
          <p className="text-sm font-semibold text-[#6B8E6B]">
            * Kalori değerleri yaklaşık hesaplamalardır. Restoranlarda küçük farklılıklar olabilir.
          </p>
        </div>
      </section>
    </div>
  );
}
