import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';

export function NotFound() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center px-4 text-center">
      <h1 className="font-display text-7xl font-bold text-[#FF8C69]">404</h1>
      <h2 className="mt-2 font-display text-2xl font-bold text-[#3D3D3D]">Sayfa bulunamadı</h2>
      <p className="mt-2 max-w-md text-[#8C8C8C]">Aradığın menüyü başka bir şehirde veya restoranda bulabilirsin.</p>
      <Link
        to="/"
        className="mt-6 inline-flex items-center gap-2 rounded-full bg-[#FF8C69] px-6 py-3 font-bold text-white shadow-md transition-transform hover:scale-105"
      >
        <Home className="h-5 w-5" /> Ana sayfaya dön
      </Link>
    </div>
  );
}
