import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SelectionSummary } from './components/SelectionSummary';
import { ScrollToTop } from './components/ScrollToTop';
import { Home } from './pages/Home';
import { CityPage } from './pages/CityPage';
import { RestaurantPage } from './pages/RestaurantPage';
import { NotFound } from './pages/NotFound';
import { SelectionProvider, useSelection } from './lib/selection';

function AppContent() {
  const { totalItems } = useSelection();

  return (
    <BrowserRouter>
      <ScrollToTop />
      <div className="flex min-h-screen flex-col bg-[#FFF8F0]">
        <Header />
        <main className={`flex-1 ${totalItems > 0 ? 'pb-24' : ''}`}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/city/:cityId" element={<CityPage />} />
            <Route path="/city/:cityId/restaurant/:restaurantId" element={<RestaurantPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
        <SelectionSummary />
      </div>
    </BrowserRouter>
  );
}

function App() {
  return (
    <SelectionProvider>
      <AppContent />
    </SelectionProvider>
  );
}

export default App;
